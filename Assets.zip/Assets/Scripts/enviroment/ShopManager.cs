using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShopManager : MonoBehaviour
{
    public Material shinyMaterial;
    public Material standardMaterial;
    bool isOpen = false;
    public SpawnerScript spawner;
    public ParticleSystem particle;
    public GameObject shopUI;
    void Start()
    {
        gameObject.GetComponent<MeshRenderer>().material = standardMaterial;
        particle.Stop();
    }

    // Update is called once per frame
    void Update()
    {
        isOpen = spawner.GetShopStatus();
        if(gameObject.GetComponent<MeshRenderer>().material != shinyMaterial && isOpen)
        {
            OpenShop();
        }
        else if (gameObject.GetComponent<MeshRenderer>().material != standardMaterial && !isOpen)
        {
            CloseShop();
        }
    }
    public void OpenShop()
    {
        gameObject.GetComponent<MeshRenderer>().material = shinyMaterial;
        particle.Play();
    }
    public void CloseShop()
    {
        gameObject.GetComponent<MeshRenderer>().material = standardMaterial;
        particle.Stop();
    }
    private void OnTriggerEnter(Collider other)
    {
        if(isOpen && other.tag == "Player")
        {
            shopUI.SetActive(true);
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            shopUI.SetActive(false);
        }
    }
}
