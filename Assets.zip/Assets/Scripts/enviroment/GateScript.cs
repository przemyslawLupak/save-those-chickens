using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GateScript : MonoBehaviour
{
    private Rigidbody[] barsBody;
    private Rigidbody _rigidbody;
    public float fenceHealt = 30;
    public Collider[] fenceColiders;
    [SerializeField]
    private bool isAttacked;
    Material material; 
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
        barsBody = GetComponentsInChildren<Rigidbody>();
        material = GetComponent<Material>();
    }

    public void Hurt(float dmg)
    {
        fenceHealt -= dmg;
        if (fenceHealt <= 0)
        {
            _rigidbody.isKinematic = false;
            foreach (Rigidbody r in barsBody)
            {
                r.isKinematic = false;
            }
        }
    }


    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "zombie" || collision.gameObject.tag == "Player")
        {
            if (fenceHealt <= 0)
            {
                for (int i = 0; i < fenceColiders.Length; i++)
                {
                    Physics.IgnoreCollision(collision.collider, fenceColiders[i]);
                }
            }
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            Physics.IgnoreCollision(other, GetComponent<Collider>());
            this.GetComponent<MeshRenderer>().material.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
            
        }
    }
}
