using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class fenceScript : MonoBehaviour
{
    private Rigidbody[] barsBody;
    private Rigidbody _rigidbody;
    public float fenceHealt = 30;
    public Collider[] fenceColiders;
    [SerializeField]
    private bool isAttacked;
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
        barsBody = GetComponentsInChildren<Rigidbody>();
    }

    public void Hurt(float dmg)
    {
        fenceHealt -= dmg;
        if(fenceHealt <= 0)
        {
            _rigidbody.isKinematic = false;
            foreach (Rigidbody r in barsBody)
            {
                r.isKinematic = false;
            }
        }
    }


    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "zombie" || collision.gameObject.tag == "Player")
        {
            if (fenceHealt <= 0)
            {
                for(int i = 0; i < fenceColiders.Length; i++)
                {
                    Physics.IgnoreCollision(collision.collider, fenceColiders[i]);
                }
            }
        }
    }
}
