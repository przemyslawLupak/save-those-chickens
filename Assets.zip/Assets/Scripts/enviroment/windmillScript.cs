using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class windmillScript : MonoBehaviour
{
    Vector3 targetAngles;
    private void Start()
    {

    }
    void Update()
    {
        transform.Rotate(0, 1, 0 * Time.deltaTime);
    }
}
