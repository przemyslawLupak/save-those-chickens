using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
public class menuScript : MonoBehaviour
{
    bool ismuted = false;
    public AudioMixer audioMixer;
    public Text soundText;
    int chcickenCounter = 6;
    public Text counterUI;
    void Awake()
    {
        
        Time.timeScale = 0; 
        
    }
    private void LateUpdate()
    {
        
        if(GameObject.FindGameObjectsWithTag("chicken")==null)
        {
            Debug.Log("u lost");
        }
    }

    public void Resume()
    {
        Time.timeScale = 1;
    }
    
    public void OnSoundClick()
    {
        if (!ismuted)
        {
            soundText.text = "Sound: Off";
            audioMixer.SetFloat("Volume", -80);
            ismuted = true;
        }
        else 
        { 
            soundText.text = "Sound: On"; 
            audioMixer.SetFloat("Volume", 0);
            ismuted = false;
        }
    }
    public void ChickenCounterDown()
    {
        chcickenCounter--;
        counterUI.text = chcickenCounter.ToString();
    }
}
