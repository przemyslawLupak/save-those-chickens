using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScript : MonoBehaviour
{
    public int waveCounter;
    public float WaveStrenghtChange=3f;
    float waveStrenght=3f;
    public float timeBetweenWaves=5f;
    public float timeBeforeStart = 20f;
    public float timeBtwZombies=0.2f;
    public float spawnTime = 0.2f;
    public GameObject[] zombies;
    public bool isSpawned = false;
    public float waveCount = 1f;
    public bool isShopOpen = false;
    void Update()
    {
        if(timeBeforeStart > 0)
        {
            timeBeforeStart -= Time.deltaTime;
        }
        else
        {
            if (spawnTime > 0)
            {
                spawnTime -= Time.deltaTime;
                
            }
            else if(spawnTime <= 0)
            {
                if (isShopOpen)
                {
                    isShopOpen = false;
                }
                GameObject newZombie = zombies[Random.Range(0, zombies.Length)];
                if(newZombie.GetComponent<zombie>().weight <= waveStrenght)
                {
                    Instantiate(newZombie,new Vector3(Random.Range(26,81),1,Random.Range(-67,51)),Quaternion.identity);
                    waveStrenght -= newZombie.GetComponent<zombie>().weight;
                }
                else if(waveStrenght == 0)
                {
                    isSpawned = true;
                    spawnTime = timeBtwZombies;
                }
                
            }
            
        }

        GameObject[] spawnedZombies = GameObject.FindGameObjectsWithTag("zombie");
        if (spawnedZombies.Length == 0 && isSpawned)
        {
            isShopOpen = true;
            timeBeforeStart = timeBetweenWaves;
            isSpawned = false;
            waveCount++;
            waveStrenght += WaveStrenghtChange + waveCount;
        }
    }
    public bool GetShopStatus()
    {
        return isShopOpen;
    }
}
