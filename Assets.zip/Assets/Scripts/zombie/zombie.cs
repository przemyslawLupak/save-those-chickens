using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zombie : MonoBehaviour
{
    public GameObject[] gate;
    Vector3 target;
    public float speed = 30f;
    GameObject[] chicken;
    float distance;
    public float weight = 1f;
    public float health = 100f;
    public bool isAttacking = false;
    public bool inAttackRange;
    public float attackDelay;
    public float timeToAttack=2f;
    public Animator animator;
    public float damage = 10;
    public GameObject attackTarget;
    public AudioSource audioSource;

    private void Awake()
    {
        audioSource.Play();
    }
    void Update()
    {
        if(target == Vector3.zero)
        {
            chicken = GameObject.FindGameObjectsWithTag("chicken");
            target = chicken[Random.Range(0, chicken.Length)].transform.position;
        }
          
        

        if (!isAttacking)
        {
            animator.SetBool("collision", false);
            Quaternion zombieRotation = Quaternion.LookRotation(target - transform.position);
            transform.eulerAngles = Vector3.Lerp(transform.eulerAngles, new Vector3(transform.eulerAngles.x,zombieRotation.eulerAngles.y, transform.eulerAngles.z), Time.deltaTime * 2f);
            transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
           
        }

        if (inAttackRange && attackDelay <= 0)
        {
            animator.SetTrigger("attack");
            Attack();
            audioSource.Play();
            attackDelay = timeToAttack;
        }
        else if(!inAttackRange)
        {
            attackDelay = timeToAttack;
        }
        else if(inAttackRange)
        {
            attackDelay -= Time.deltaTime;
        }
    }

    public void OnChickenDestroy()
    {
        chicken = GameObject.FindGameObjectsWithTag("chicken");
        if(chicken.Length != 0) 
        {
            target = chicken[Random.Range(0, chicken.Length)].transform.position;
        }
        else
        {
            animator.SetBool("collision", true);
            target = transform.position;
        }
    }


    void Hurt(float damage)
    {
        if((health - damage) > 0)
        {
            health -= damage;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public void Attack()
    {
        if(attackTarget != null)
        {        
            if (attackTarget.tag == "Player")
            {
                attackTarget.GetComponent<PlayerManager>().Hurt(damage);
            }
            else if (attackTarget.tag == "fence")
            {
                attackTarget.GetComponent<fenceScript>().Hurt(damage);
            }
            else if (attackTarget.tag == "gate")
            {
                attackTarget.GetComponent<GateScript>().Hurt(damage);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "projectaile")
        {
            Hurt(collision.gameObject.GetComponent<PorjectalMove>().damage);
        }
        if (collision.gameObject.tag == "Player" || collision.gameObject.tag == "fence" || collision.gameObject.tag == "chicken" || collision.gameObject.tag == "gate")
        {
            isAttacking = true;
            inAttackRange = true;
            animator.SetBool("collision", true);
            attackTarget = collision.gameObject;
        }
        
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "Player" || collision.gameObject.tag == "fence" || collision.gameObject.tag == "chicken" || collision.gameObject.tag == "gate")
        {
            isAttacking = false;
            inAttackRange = false;
            animator.SetBool("collision", false);
            attackTarget = null;
        }
    }
}
