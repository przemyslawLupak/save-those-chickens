using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
public class ChickenScript : MonoBehaviour
{
    public Vector3 targetAngles;
    public bool isFar = false;
    public Transform farmCenter;
    public float jumpDelay = 3f;
    public float timeToJump = 3f;
    Rigidbody _rigidbody;
    public bool isJumping = false;
    public Transform ground;
    public LayerMask groundMask;
    public bool isGrounded;
    public float health = 10;
    public AudioSource audioSource;
    public GameObject menuUI;
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
        targetAngles = transform.eulerAngles;
        targetAngles.y = 0;
        targetAngles =targetAngles + Random.Range(0, 180) * Vector3.up;
        GameObject player = GameObject.FindGameObjectWithTag("Player");
    }

    void Update()
    {

        isGrounded = Physics.CheckSphere(ground.position, 0.5f, groundMask);

        if (targetAngles != transform.eulerAngles && isGrounded)
        {
            transform.eulerAngles = Vector3.Lerp(transform.eulerAngles, targetAngles,10f * Time.deltaTime);
        }
        if (timeToJump <= 0 && isGrounded){
            targetAngles = SetAngle();
            timeToJump = jumpDelay;
            isJumping = false;
        }
        else if((timeToJump <= (jumpDelay / 3)) && isJumping == false && isGrounded)
        {
            _rigidbody.AddForce(transform.up * 300f) ;
            _rigidbody.AddForce(transform.forward * 100f);

            isJumping = true;
        }
        else if(timeToJump>0 && isGrounded) 
        {
            timeToJump -= Time.deltaTime;
        }
    }


    Vector3 SetAngle()
    {
        float x = transform.position.x;
        float z = transform.position.z;
        if (x < -28.9 || x > -10.42 || z < -25 || z > 28.6)
        {
            Quaternion chickenRotation = Quaternion.LookRotation(farmCenter.position - transform.position);
            return new Vector3(transform.eulerAngles.x, chickenRotation.eulerAngles.y, transform.eulerAngles.z);

        }
        else if (z > 9.1 && x < -18)
        {
            Quaternion chickenRotation = Quaternion.LookRotation(farmCenter.position - transform.position);
            return new Vector3(transform.eulerAngles.x, chickenRotation.eulerAngles.y + 90f, transform.eulerAngles.z);
        }
        else
        {
            targetAngles.y = 0;
            return targetAngles + Random.Range(0, 180) * Vector3.up;

        }
        
    }
    
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" )
        {
            Physics.IgnoreCollision(other, GetComponent<Collider>());
        }
       
        if ( other.tag == "zombie")
        {
            audioSource.Play();
            menuUI.GetComponent<menuScript>().ChickenCounterDown();
            other.GetComponent<zombie>().OnChickenDestroy();
            Destroy(gameObject);
           
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "zombie") 
        {
            audioSource.Play();
            menuUI.GetComponent<menuScript>().ChickenCounterDown();
            collision.gameObject.GetComponent<zombie>().OnChickenDestroy();
            Destroy(gameObject);
        }
    }
  
}
