using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChickenSpawnerScript : MonoBehaviour
{
    float spawnTime = 0;
    float timeBtwChickens = 0.2f;
    public GameObject chickens;
    int chickenCount = 0;
    void LateUpdate()
    {
        if (spawnTime > 0 && chickenCount<7)
        {
            spawnTime -= Time.deltaTime;

        }
        else if (spawnTime <= 0 && chickenCount < 7)
        {    
            Instantiate(chickens, new Vector3(Random.Range(-28, -11), 2.18f, Random.Range(-25, 7)), Quaternion.identity);
            spawnTime = timeBtwChickens;
            chickenCount++;
        }
    }


}
