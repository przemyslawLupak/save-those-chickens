using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    InputManager inputManager;
    PlayerLocomotion playerLocomotion;
    public float Helath = 100;

    private void Awake()
    {
        inputManager = GetComponent<InputManager>();
        playerLocomotion = GetComponent<PlayerLocomotion>();
    }

    private void Update()
    {
        inputManager.HandleAllInputs();   
    }

    private void FixedUpdate()
    {
        playerLocomotion.HandleAllMovement(); 
    }
    public void Hurt(float dmg)
    {
        Helath =- dmg;
        if(Helath <= 0)
        {
            Destroy(gameObject);
        }
    }
}
