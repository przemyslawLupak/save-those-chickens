 using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnProjectail : MonoBehaviour
{
    public GameObject firePoint;
    public List<GameObject> vfx = new List<GameObject>();

    public PlayerLocomotion playerRotation;
    private GameObject effectToSpawn;
    private float timeToFire=1f;
    private bool isShooting = false;
    public AudioSource shootSound;
    void Start()
    {
        effectToSpawn = vfx[0];
    }

    // Update is called once per frame
    void Update()
    {
        if(isShooting && Time.time >= timeToFire)
        {
            timeToFire = Time.time + 1 / effectToSpawn.GetComponent<PorjectalMove>().fireRate;
            SpawnVFX();
            shootSound.Play();
        }
    }

    void SpawnVFX()
    {
        GameObject vfx;
        if(firePoint != null)
        {
            vfx = Instantiate(effectToSpawn, firePoint.transform.position, Quaternion.identity);
            if(playerRotation != null)
            {
                vfx.transform.localRotation= playerRotation.GetRotation();
            }
        }
        else
        {
            Debug.Log("No fire Point");
        }
    }
    public void Shooting(bool _shoot)
    {
        isShooting = _shoot;
    }
}
