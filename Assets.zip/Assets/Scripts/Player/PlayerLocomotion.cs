using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLocomotion : MonoBehaviour
{
    InputManager inputManager;
    Vector3 moveDirection;
    Transform cameraObject;
    Rigidbody playerRigitbody;
    public Animator anim;
    public LayerMask groundMask;
    public Transform groundCheck;
    [SerializeField] private bool isGrounded;
    private GameObject[] enemies;
    public float groundDistance = 0.4f;
    public float movementSpeed = 7;
    public float rotationSpeed = 15;
    public float shotingRange = 10f;
    SpawnProjectail spawnProjectail;
    public Transform playerBody;
    public AudioSource grassSteps;
    float stepsFrequency = 0.4f;
    float timeToStep = 0;
    private void Awake()
    {
        inputManager = GetComponent<InputManager>();
        playerRigitbody = GetComponent<Rigidbody>();
        cameraObject = Camera.main.transform;
        spawnProjectail = GetComponent<SpawnProjectail>();
    }

    public void HandleAllMovement()
    {
        HandleMovement();
        HandleRotation();
    }
    private void HandleMovement()
    {
        moveDirection = cameraObject.forward * inputManager.verticalInput;
        moveDirection = moveDirection + cameraObject.right * inputManager.horizontalInput;
        moveDirection.Normalize();
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
        if (!isGrounded)
        {
            moveDirection.y = -0.4f;
        }
        else
        {
            moveDirection.y = 0;
        }
        moveDirection = moveDirection * movementSpeed;

        Vector3 movementVelocity = moveDirection;
        playerRigitbody.velocity = movementVelocity;
        if(playerRigitbody.velocity != Vector3.zero && Time.time >= timeToStep)
        {
            grassSteps.Play();
            timeToStep = stepsFrequency + Time.time;
        }
       
        anim.SetFloat("speed", moveDirection.magnitude, 0.1f, Time.deltaTime);
    }

    private void HandleRotation()
    {
        Vector3 targetDirection= Vector3.zero;
        targetDirection = cameraObject.forward * inputManager.verticalInput;
        targetDirection = targetDirection + cameraObject.right * inputManager.horizontalInput;
        targetDirection.Normalize();
        targetDirection.y = 0;

        Quaternion targetRotation = Quaternion.LookRotation(targetDirection);
        Quaternion playerRotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        enemies = GameObject.FindGameObjectsWithTag("zombie");
        if (enemies.Length > 0) 
        {
            Transform enemyPosition = GetClosestEnemy(enemies);
            float enemyDistance = Vector3.Distance(enemyPosition.position, transform.position);

            if (shotingRange > enemyDistance && targetDirection == Vector3.zero)
            {
                playerRotation = Quaternion.LookRotation(enemyPosition.position - transform.position);
                transform.rotation = Quaternion.Slerp(transform.rotation, playerRotation, Time.deltaTime * rotationSpeed);
                spawnProjectail.Shooting(true);
            }
            else if(shotingRange < enemyDistance && targetDirection == Vector3.zero)
            {
                playerRotation = Quaternion.LookRotation(transform.forward);
                transform.rotation = Quaternion.Slerp(transform.rotation, playerRotation, Time.deltaTime * rotationSpeed);
                spawnProjectail.Shooting(false);
            }
            else
            {
                transform.rotation = playerRotation;
                spawnProjectail.Shooting(false);
            }
        }
        else if(targetDirection == Vector3.zero)
        {
            playerRotation = Quaternion.LookRotation(transform.forward);
            transform.rotation = Quaternion.Slerp(transform.rotation, playerRotation, Time.deltaTime * rotationSpeed);
            spawnProjectail.Shooting(false);

        }
        else
        {
            transform.rotation = playerRotation;
            spawnProjectail.Shooting(false);
        }
    }

    public Transform GetClosestEnemy(GameObject[] enemies)
    {
        Transform tMin = null;
        float minDist = Mathf.Infinity;
        Vector3 currentPos = transform.position;
        foreach (GameObject t in enemies)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist < minDist)
            {
                tMin = t.transform;
                minDist = dist;
            }
        }
        return tMin;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, shotingRange);
    }

    public Quaternion GetRotation()
    {
        return playerBody.localRotation;
    }
}
